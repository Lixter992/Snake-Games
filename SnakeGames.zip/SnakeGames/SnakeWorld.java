import lang.stride.*;
import java.util.*;
import greenfoot.*;

/**
 * 
 */
public class SnakeWorld extends World
{

    /**
     * Constructor for objects of class SnakeWorld.
     */
    public SnakeWorld()
    {
        super(50, 25, 20);
        
        GreenfootImage img = new GreenfootImage(20,20);
        img.setColor(Color.GREEN);
        img.fill();
        setBackground(img);
        
        int x = Greenfoot.getRandomNumber(getWidth());
        int y = Greenfoot.getRandomNumber(getHeight());
        addObject(new Snake(), x, y);
        
        addFood();
    } 
    
    public void addFood()
    {
        int x = Greenfoot.getRandomNumber(getWidth());
        int y = Greenfoot.getRandomNumber(getHeight());
        addObject(new Food(), x, y);
    }
}
