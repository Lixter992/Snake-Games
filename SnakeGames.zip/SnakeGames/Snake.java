import lang.stride.*;
import java.util.*;
import greenfoot.*;

/**
 * 
 */
public class Snake extends Actor
{
    private final int EAST = 0;
    private final int SOUTH = 90;
    private final int WEST = 180;
    private final int NORTH = 270;
    
    private final int SPEED = 10;
    private int counter = 0;
    
    private int foodEaten = 0;
    
    public Snake()
    {
        GreenfootImage img = new GreenfootImage(20,20);
        img.fill();
        setImage(img);
        
        setRotation(Greenfoot.getRandomNumber(4)*90);
    }
    
    /**
     * Act - do whatever the Snake wants to do. This method is called whenever the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        moveAround();
        if (isTouching(Food.class)) {
            removeTouching(Food.class);
            foodEaten++;
            SnakeWorld world = (SnakeWorld)getWorld();
            world.addFood();
        }
        if (facingEdge()) {
            Greenfoot.stop();
        }
    }
    
    private boolean facingEdge()
    {
        switch(getRotation()) {
            case EAST: return getX() == getWorld().getWidth()-1;
            case SOUTH: return getY() == getWorld().getHeight()-1;
            case WEST: return getX() == 0;
            case NORTH: return getY() == 0;
        }
        return false;
    }
    
    private void moveAround()
    {
        counter ++;
        if (counter == SPEED) {
            getWorld().addObject(new Tail(foodEaten*SPEED), getX(), getY());
            move(1);
            counter = 0;
        }
        
        if (Greenfoot.isKeyDown("right") && getRotation() != WEST) {
            setRotation(EAST);
        }
        
        if (Greenfoot.isKeyDown("down") && getRotation() != NORTH) {
            setRotation(SOUTH);
        }
        
        if (Greenfoot.isKeyDown("left") && getRotation() != EAST) {
            setRotation(WEST);
        }
        
        if (Greenfoot.isKeyDown("up") && getRotation() != SOUTH) {
            setRotation(NORTH);
        }
    }
}
