import greenfoot.*;
/**
 * 
 */
public class Food extends Actor
{
    public Food()
    {
        GreenfootImage img = new GreenfootImage(20,20);
        img.setColor(Color.RED);
        img.fill();
        setImage(img);
    }
    
    /**
     * Act - do whatever the Food wants to do. This method is called whenever the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
    }
}
